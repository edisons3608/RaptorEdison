﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.greenLight = New System.Windows.Forms.TextBox()
        Me.yellowLight = New System.Windows.Forms.TextBox()
        Me.redLight = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'greenLight
        '
        Me.greenLight.Location = New System.Drawing.Point(363, 271)
        Me.greenLight.Multiline = True
        Me.greenLight.Name = "greenLight"
        Me.greenLight.Size = New System.Drawing.Size(68, 68)
        Me.greenLight.TabIndex = 0
        '
        'yellowLight
        '
        Me.yellowLight.Location = New System.Drawing.Point(363, 173)
        Me.yellowLight.Multiline = True
        Me.yellowLight.Name = "yellowLight"
        Me.yellowLight.Size = New System.Drawing.Size(68, 68)
        Me.yellowLight.TabIndex = 1
        '
        'redLight
        '
        Me.redLight.Location = New System.Drawing.Point(363, 75)
        Me.redLight.Multiline = True
        Me.redLight.Name = "redLight"
        Me.redLight.Size = New System.Drawing.Size(68, 68)
        Me.redLight.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.redLight)
        Me.Controls.Add(Me.yellowLight)
        Me.Controls.Add(Me.greenLight)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents greenLight As TextBox
    Friend WithEvents yellowLight As TextBox
    Friend WithEvents redLight As TextBox
End Class
